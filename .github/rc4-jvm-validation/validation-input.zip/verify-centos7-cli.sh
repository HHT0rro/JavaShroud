#!/usr/bin/env bash
set -euo pipefail
cp /evidence/cli-original.jar /tmp/jsh-original.jar
sha256sum /tmp/jsh-original.jar > /evidence/centos7-calc-input-before.txt
cat > /evidence/centos7-minimal.toml <<'TOML'
inputJarPath = "/tmp/jsh-original.jar"
outputJarPath = "/evidence/centos7-minimal.jar"
protectionProfile = "minimal"

[[passes]]
id = "strip-compile-debug-info"
enabled = true
TOML
java -Xmx256m -XX:ActiveProcessorCount=2 -jar /tmp/jsh-original.jar > /evidence/centos7-calc-original.stdout.log 2> /evidence/centos7-calc-original.stderr.log
bin/core-engine -config /evidence/centos7-minimal.toml > /evidence/centos7-calc-transform.stdout.log 2> /evidence/centos7-calc-transform.stderr.log
java -Xmx256m -XX:ActiveProcessorCount=2 -jar /evidence/centos7-minimal.jar > /evidence/centos7-calc-processed.stdout.log 2> /evidence/centos7-calc-processed.stderr.log
grep -Fxq 'COUNT=30000' /evidence/centos7-calc-original.stdout.log
grep -Fxq 'COUNT=30000' /evidence/centos7-calc-processed.stdout.log
grep -q 'passes=1' /evidence/centos7-calc-transform.stdout.log
test ! -s /evidence/centos7-calc-original.stderr.log
test ! -s /evidence/centos7-calc-transform.stderr.log
test ! -s /evidence/centos7-calc-processed.stderr.log
sed 's|/evidence/centos7-minimal.jar|/tmp/jsh-original.jar|' /evidence/centos7-minimal.toml > /evidence/centos7-collision.toml
set +e
bin/core-engine -config /evidence/centos7-collision.toml > /evidence/centos7-calc-collision.stdout.log 2> /evidence/centos7-calc-collision.stderr.log
collision_result=$?
set -e
printf '%s\n' "$collision_result" > /evidence/centos7-calc-collision.exit
test "$collision_result" = 1
grep -q 'Output or sidecar path refers to a protected run file' /evidence/centos7-calc-collision.stderr.log
sha256sum /tmp/jsh-original.jar > /evidence/centos7-calc-input-after.txt
cmp /evidence/centos7-calc-input-before.txt /evidence/centos7-calc-input-after.txt
printf 'ORIGINAL_COUNT=30000\nPROCESSED_COUNT=30000\nSTRIP_PASSES=1\nCOLLISION_EXIT=1\nINPUT_UNCHANGED=yes\n' > /evidence/centos7-cli-result.txt
