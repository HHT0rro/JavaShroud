#!/usr/bin/env bash
set -euo pipefail
mkdir -p /tmp/jsh-jdk /tmp/jsh-app
printf '51fb4d03a4429c39d397d3a03a779077159317616550e4e71624c9843083e7b9  /tools/OpenJDK21U-jdk_x64_linux_hotspot_21.0.4_7.tar.gz\n' | sha256sum -c -
printf '%s  /package\n' "$EXPECTED_ARCHIVE_SHA256" | sha256sum -c -
tar -xzf /tools/OpenJDK21U-jdk_x64_linux_hotspot_21.0.4_7.tar.gz -C /tmp/jsh-jdk --strip-components=1
tar -xf /package -C /tmp/jsh-app
export JAVA_HOME=/tmp/jsh-jdk
export PATH=/tmp/jsh-jdk/bin:/usr/bin:/bin
export JAVA_OPTS='-Xmx256m -XX:ActiveProcessorCount=2'
unset JAVA_TOOL_OPTIONS JDK_JAVA_OPTIONS _JAVA_OPTIONS
/lib64/libc.so.6 > /evidence/centos7-glibc.log 2>&1
java -version > /evidence/centos7-java-version.log 2>&1
cd "/tmp/jsh-app/core-engine-$EXPECTED_VERSION"
stat -c '%a %F %n' bin/core-engine > /evidence/centos7-launcher-mode.log
printf '%s  lib/obfuscator-engine-%s.jar\n' "$EXPECTED_ENGINE_SHA256" "$EXPECTED_VERSION" | sha256sum -c -
set +e
bin/core-engine -schema > /evidence/centos7-launcher-schema.stdout.log 2> /evidence/centos7-launcher-schema.stderr.log
result=$?
set -e
printf '%s\n' "$result" > /evidence/centos7-launcher-schema.exit
test "$result" = 0
grep -Fxq "schemaVersion = '2'" /evidence/centos7-launcher-schema.stdout.log
grep -Fxq "engineVersion = '$EXPECTED_VERSION'" /evidence/centos7-launcher-schema.stdout.log
test ! -s /evidence/centos7-launcher-schema.stderr.log
ldd /evidence/native/libqp_ffi.so > /evidence/centos7-ldd.log 2>&1
if grep -q 'not found' /evidence/centos7-ldd.log; then exit 20; fi
set +e
java -Xmx256m -XX:ActiveProcessorCount=2 -cp "/evidence/probe:/tmp/jsh-app/core-engine-$EXPECTED_VERSION/lib/*" io.github.hht0rro.javashroud.QpBridgeProbe /evidence/native/libqp_ffi.so linux-x64 > /evidence/centos7-jni-probe.stdout.log 2> /evidence/centos7-jni-probe.stderr.log
result=$?
set -e
printf '%s\n' "$result" > /evidence/centos7-jni-probe.exit
test "$result" = 0
grep -Fxq 'INIT=0' /evidence/centos7-jni-probe.stdout.log
grep -Fxq 'BEAT=0' /evidence/centos7-jni-probe.stdout.log
grep -Fxq 'SESSION=ok' /evidence/centos7-jni-probe.stdout.log
grep -Fxq 'UNBOUND=ok' /evidence/centos7-jni-probe.stdout.log
test ! -s /evidence/centos7-jni-probe.stderr.log
printf 'GLIBC217_SCHEMA=ok\nINIT=0\nBEAT=0\nSESSION=ok\nUNBOUND=ok\n' > /evidence/centos7-result.txt
if test -f /evidence/verify-centos7-cli.sh; then
  source /evidence/verify-centos7-cli.sh
fi
